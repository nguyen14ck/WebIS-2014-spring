<?php
## PHP documentation toc.xml generator for eclipse.
## Written by Timothy Middelkoop.  Released to the public domain.

$toc=<<<XML
<?xml version="1.0" encoding="utf-8" standalone="no"?>
<toc label="PHP 5.4 Reference Manual" topic="php-chunked-xhtml/index.html">
</toc>
XML;

$dom = new DOMDocument;
$dom->loadHTMLFile('php-chunked-xhtml/index.html');
$xml = simplexml_import_dom($dom);
$index = $xml->xpath('//div[@id="index"]/ul');
$toc = new SimpleXMLelement($toc);

function expand($n,$x){
	foreach($n as $c){
		if($c->getName()=='li'){
			$t=$x->addChild('topic');
			$t['label']=(string)$c->a;
			$t['href']='php-chunked-xhtml/'.$c->a['href'];
			expand($c,$t);
		}else{
			expand($c,$x);
		}
	}
}

expand($index,$toc);
$toc->asXML('toc.xml');

?>